import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-main',
  templateUrl: './mobile-main.component.html',
  styleUrls: ['./mobile-main.component.css']
})
export class MobileMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
