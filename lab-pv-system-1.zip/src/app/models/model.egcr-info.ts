export class EGCR_Info{
    EGCR_ID: Number; //Unique ID for each EGCR page
    Lat: Number; //Latitude for google maps
    Lan: Number; //Longitude for google maps
}